// Elements
const container = document.getElementById("video-container");
const video = document.getElementById("video");
const videoControls = document.getElementById("video-controls");
const playButton = document.getElementById("play");
const playbackIcons = document.querySelectorAll(".playback-icons use");
const timeElapsed = document.getElementById("time-elapsed");
const duration = document.getElementById("duration");
const progressBar = document.getElementById("progress-bar");
const seek = document.getElementById("seek");
const seekTooltip = document.getElementById("seek-tooltip");

const close = document.getElementById("close");
const toggle = document.getElementById("toggle-video");

const progressContainer = document.querySelector(".video-progress");
const timeContainer = document.querySelector(".time");

// if (video.readyState > 0) {
//     console.log("video ready");
// } else {
// 	console.log("not ready..");
// }
video.addEventListener('canplaythrough', (event) => {
  console.log('I think I can play through the entire ' +
      'video without ever having to stop to buffer.');
});

video.addEventListener("loadedmetadata", initializeVideo);


const videoWorks = !!document.createElement("video").canPlayType;

if (videoWorks) {
    video.controls = false;
    videoControls.classList.remove("hidden");
}

function closePlayer() {
    container.classList.add('hidden')
    videoControls.classList.add("hidden");
    close.classList.add("hidden");
    play.classList.add("hidden");
    video.classList.add("hidden");
    // only show the button
    toggle.classList.remove("hidden");
}

function openPlayer() {
    toggle.classList.add("hidden");

    // show the rest
	container.classList.remove('hidden')
    videoControls.classList.remove("hidden");
    close.classList.remove("hidden");
    play.classList.remove("hidden");
    video.classList.remove("hidden");
	video.load();
}

function showControls() {
	videoControls.classList.remove("hidden");
    close.classList.remove("hidden");
	play.classList.remove("hidden");
	progressContainer.classList.remove("hidden");
    timeContainer.classList.remove("hidden");
}

function hideControls() {
	videoControls.classList.add("hidden");
    close.classList.add("hidden");
	play.classList.add("hidden");
	progressContainer.classList.add("hidden");
    timeContainer.classList.add("hidden");
}

// toggles playback state of the video
function togglePlay() {
	if (video.paused || video.ended) {
		seek.value = Math.floor(video.currentTime);
        progressBar.value = Math.floor(video.currentTime);
        video.play();
    } else {
        video.pause();
    }
}

// update the pause and pay button
function updatePlayButton() {
    playbackIcons.forEach((icon) => icon.classList.toggle("hidden"));
}

// formatTime takes a time in seconds and returns the time in
// minutes and seconds
function formatTime(timeInSeconds) {
    const result = new Date(timeInSeconds * 1000).toISOString().substr(11, 8);

    return {
        minutes: result.substr(3, 2),
        seconds: result.substr(6, 2),
    };
}

// updateTimeElapsed indicates how far through the video
// the current playback is
function updateTimeElapsed() {
    const time = formatTime(Math.round(video.currentTime));
    timeElapsed.innerText = `${time.minutes}:${time.seconds}`;
    timeElapsed.setAttribute("datetime", `${time.minutes}m ${time.seconds}s`);
    // console.log({ timeElapsed });
}

// initializeVideo sets the video duration, and maximum value of the
// progressBar
function initializeVideo(e) {
    const videoDuration = Math.round(video.duration);
    console.log({ e });
    seek.setAttribute("max", videoDuration);
    progressBar.setAttribute("max", videoDuration);
    const time = formatTime(videoDuration);
    duration.innerText = `${time.minutes}:${time.seconds}`;
    duration.setAttribute("datetime", `${time.minutes}m ${time.seconds}s`);
    console.log({ duration });
}

// updateProgress indicates how far through the video
// the current playback is by updating the progress bar
function updateProgress() {
    seek.value = Math.floor(video.currentTime + 1);
    progressBar.value = Math.floor(video.currentTime + 1);
}

// updateSeekTooltip uses the position of the mouse on the progress bar to
// roughly work out what point in the video the user will skip to if
// the progress bar is clicked at that point
function updateSeekTooltip(event) {
    const skipTo = Math.round((event.offsetX / event.target.clientWidth) * parseInt(event.target.getAttribute("max"), 10));
    seek.setAttribute("data-seek", skipTo);
    const t = formatTime(skipTo);
    seekTooltip.textContent = `${t.minutes}:${t.seconds}`;
    const rect = video.getBoundingClientRect();
    seekTooltip.style.left = `${event.pageX - rect.left}px`;
}

// Event listeners
// if (video.readyState > 0) {
// 	console.log('video ready');
// 	video.addEventListener("loadedmetadata", initializeVideo);
// 	// debugger;
// } else {
// 	console.log('not ready..')
// }

playButton.addEventListener("click", togglePlay);
video.addEventListener("play", updatePlayButton);
video.addEventListener("pause", updatePlayButton);
video.addEventListener("timeupdate", updateTimeElapsed);
video.addEventListener("timeupdate", updateProgress);
container.addEventListener('mouseover', showControls);
container.addEventListener('mouseleave', hideControls);
close.addEventListener("click", closePlayer);
toggle.addEventListener("click", openPlayer);
seek.addEventListener("mousemove", updateSeekTooltip);
